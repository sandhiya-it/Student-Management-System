# Student Management System

A beginner-friendly Java web application demonstrating:

- HTML/CSS frontend
- Jakarta Servlet
- Core Java
- JDBC
- MySQL
- Apache Tomcat
- Maven
- CRUD operations
- DAO pattern
- Basic server-side validation

## Technology

- Java 17+
- Maven
- Tomcat 10.1+
- Jakarta Servlet 6
- MySQL 8+
- Eclipse or IntelliJ IDEA

## Project Structure

```text
StudentManagementSystem/
├── pom.xml
├── database/
│   └── student_management.sql
└── src/
    └── main/
        ├── java/
        │   └── com/studentmanagement/
        │       ├── dao/
        │       │   └── StudentDAO.java
        │       ├── model/
        │       │   └── Student.java
        │       ├── util/
        │       │   ├── DBConnection.java
        │       │   └── ValidationUtil.java
        │       └── web/
        │           └── StudentServlet.java
        └── webapp/
            ├── index.jsp
            ├── css/
            │   └── style.css
            └── WEB-INF/
                └── views/
                    ├── student-form.jsp
                    ├── student-list.jsp
                    └── error.jsp
```

## 1. Create the database

Open MySQL Workbench or the MySQL command line and run:

```sql
source path/to/database/student_management.sql;
```

Or open the SQL file and execute it manually.

This creates:

- database: `student_management`
- table: `students`
- two sample students

## 2. Configure MySQL password

Open:

```text
src/main/java/com/studentmanagement/util/DBConnection.java
```

Change:

```java
private static final String PASSWORD = "YOUR_MYSQL_PASSWORD";
```

to your actual MySQL password.

If your MySQL username is not `root`, change the USER value too.

## 3. Build with Maven

From the project directory:

```bash
mvn clean package
```

The WAR file will be generated under:

```text
target/StudentManagementSystem.war
```

## 4. Run with Tomcat

Install Apache Tomcat 10.1.

Copy:

```text
target/StudentManagementSystem.war
```

into:

```text
TOMCAT_HOME/webapps/
```

Start Tomcat.

Then open:

```text
http://localhost:8080/StudentManagementSystem/
```

## 5. Run from Eclipse

1. Import the project as an Existing Maven Project.
2. Make sure Java 17+ is configured.
3. Add/configure a Tomcat 10.1 server.
4. Add the project to the Tomcat server.
5. Start the server.
6. Open the application URL.

## CRUD flow

### Add

HTML/JSP form
→ StudentServlet
→ StudentDAO
→ JDBC
→ MySQL INSERT

### View

StudentServlet
→ StudentDAO
→ JDBC SELECT
→ MySQL
→ JSP table

### Update

Edit
→ StudentServlet
→ StudentDAO
→ JDBC UPDATE
→ MySQL

### Delete

Delete
→ StudentServlet
→ StudentDAO
→ JDBC DELETE
→ MySQL

## Important interview explanation

The application follows a simple layered structure:

```text
Frontend
HTML/CSS/JSP
       ↓
Web Layer
StudentServlet
       ↓
DAO Layer
StudentDAO
       ↓
JDBC
       ↓
MySQL
```

Tomcat acts as the Servlet container and web server.

Maven manages project dependencies and creates the WAR package.

## Important note

This is an educational project. For production use, credentials should not be hardcoded, authentication/authorization should be added, logging should be improved, database connections should use pooling, and security/testing/deployment practices should be strengthened.
