CREATE DATABASE IF NOT EXISTS student_management;
USE student_management;

CREATE TABLE IF NOT EXISTS students (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    department VARCHAR(50) NOT NULL,
    grade VARCHAR(10) NOT NULL
);

INSERT INTO students (id, name, email, department, grade)
VALUES
(101, 'Arun Kumar', 'arun@example.com', 'IT', 'A'),
(102, 'Priya Raj', 'priya@example.com', 'CSE', 'A+')
ON DUPLICATE KEY UPDATE
name = VALUES(name),
email = VALUES(email),
department = VALUES(department),
grade = VALUES(grade);
